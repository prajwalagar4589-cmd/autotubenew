import os, logging, datetime as dt, yaml
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
WORK = ROOT / "work"
ASSETS = ROOT / "assets"
DATA.mkdir(exist_ok=True); WORK.mkdir(exist_ok=True)

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("autotube")

def load_config():
    with open(ROOT / "config.yaml") as f:
        return yaml.safe_load(f)

def ist_now():
    return dt.datetime.utcnow() + dt.timedelta(hours=5, minutes=30)

class Abort(Exception):
    """Fail-closed: raised when any gate fails. The day is skipped, nothing is posted."""
