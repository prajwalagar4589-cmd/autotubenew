import time, calendar, feedparser, requests, re, html
from .common import log

UA = {"User-Agent": "Mozilla/5.0 (compatible; autotube-ingest/1.0)"}

def _clean(s, n=600):
    s = html.unescape(re.sub(r"<[^>]+>", " ", s or ""))
    return re.sub(r"\s+", " ", s).strip()[:n]

def fetch(urls, max_age_hours=48, skip_urls=()):
    items, health = [], {}
    cutoff = time.time() - max_age_hours * 3600
    for url in urls:
        try:
            r = requests.get(url, headers=UA, timeout=25); r.raise_for_status()
            feed = feedparser.parse(r.content)
            n = 0
            for e in feed.entries[:40]:
                ts = e.get("published_parsed") or e.get("updated_parsed")
                t = calendar.timegm(ts) if ts else time.time()
                link = e.get("link", "")
                if t < cutoff or not link or link in skip_urls:
                    continue
                items.append({"title": _clean(e.get("title"), 200), "summary": _clean(e.get("summary")),
                              "url": link, "source": feed.feed.get("title", url)[:60], "ts": t})
                n += 1
            health[url] = f"ok ({n} fresh)"
        except Exception as ex:
            health[url] = f"FAILED: {str(ex)[:80]}"
    for u, h in health.items():
        log.info(f"feed {h}: {u}")
    seen, out = set(), []
    for it in sorted(items, key=lambda x: -x["ts"]):
        key = it["title"].lower()[:70]
        if key not in seen:
            seen.add(key); out.append(it)
    return out[:40], health
