import os, requests
from .common import log

def send(text):
    tok, chat = os.environ.get("TELEGRAM_BOT_TOKEN"), os.environ.get("TELEGRAM_CHAT_ID")
    log.info(f"ALERT: {text}")
    if not tok or not chat:
        return
    try:
        requests.post(f"https://api.telegram.org/bot{tok}/sendMessage", timeout=20,
                      json={"chat_id": chat, "text": text[:4000], "disable_web_page_preview": True})
    except Exception as e:
        log.warning(f"telegram failed: {e}")
