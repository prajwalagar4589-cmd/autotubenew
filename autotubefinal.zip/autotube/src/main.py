"""Daily run. Fail-closed: any failed gate means no post today, plus an alert.
Env: DRY_RUN=1 (render but don't upload), FORCE=1 (run even if today's post exists)."""
import os, sys, shutil, json, random, traceback
from .common import load_config, log, ist_now, Abort, WORK, ROOT, DATA
from . import db, ingest, writer, tts, render, qa, youtube, alert

def choose_format(cfg):
    recent = db.recent_formats(3)
    options = [f for f in cfg["formats"] if f.split(":")[0] not in [r.split(":")[0] for r in recent if r]]
    return random.choice(options or cfg["formats"])

def build_description(cfg, pillar, script, material):
    comp = cfg["compliance"]
    srcs = "\n".join(f"- {m['source']}: {m['url']}" for m in material)
    parts = [script["description"], "", "Sources:", srcs, "", comp["ai_disclosure"]]
    if pillar in comp["finance_pillars"]:
        parts.append(comp["finance_disclaimer"])
    parts += ["Stock footage: Pexels.", "",
              f"{cfg['channel']['name']}: {cfg['channel']['tagline']}", "",
              " ".join("#" + t.replace(" ", "") for t in (["shorts"] + script.get("tags", [])[:4]))]
    return "\n".join(parts)

def run():
    cfg = load_config()
    now = ist_now(); day = now.strftime("%Y-%m-%d")
    dry = bool(os.environ.get("DRY_RUN")); force = bool(os.environ.get("FORCE"))
    if db.already_ran(day) and not force:
        log.info("Already published today, exiting."); return
    pillar = cfg["pillars"][now.weekday()]
    fmt = choose_format(cfg)
    insights_path = DATA / "insights.md"
    insights = insights_path.read_text()[:2500] if insights_path.exists() else "No data yet."
    recent = db.recent_titles(60)
    log.info(f"Day {day}: pillar={pillar} format={fmt.split(':')[0]}")

    ctx = {"day": day, "pillar": pillar, "format": fmt}
    try:
        if pillar in cfg["evergreen_pillars"]:
            pick = writer.pick_evergreen(pillar, fmt, recent, insights)
        else:
            items, health = ingest.fetch(cfg["sources"][pillar], 48, db.used_urls())
            if len(items) < cfg["min_items_for_news"]:
                items, health = ingest.fetch(cfg["sources"][pillar], 120, db.used_urls())
            if len(items) < cfg["min_items_for_news"]:
                log.warning("Too little fresh news; making an evergreen video on this pillar instead")
                pick = writer.pick_evergreen(pillar, fmt, recent, insights)
            else:
                sel = writer.pick_news(pillar, items, fmt, recent, insights)
                chosen = [items[i] for i in sel["picks"][:3]]
                material = [{"url": it["url"], "source": it["source"],
                             "text": writer.article_text(it["url"], it["title"] + ". " + it["summary"])} for it in chosen]
                pick = {"topic": sel["topic"], "angle": sel["angle"], "material": material}
        material = pick["material"]
        ctx.update(topic=pick["topic"], source_urls=[m["url"] for m in material])

        script = writer.produce(pillar, fmt, pick["topic"], pick["angle"], material)
        ctx.update(title=script["title"], script_json=script)
        wav, seg_t, words = tts.synthesize(script["segments"])
        if seg_t[-1][1] > cfg["publish"]["max_duration_sec"]:
            raise Abort(f"Narration too long ({seg_t[-1][1]:.1f}s)")
        video = render.render(script, wav, seg_t, words, pillar)
        dur = qa.check(video)
        out = ROOT / "out"; out.mkdir(exist_ok=True); shutil.copy(video, out / f"{day}_{pillar}.mp4")
        (out / f"{day}_{pillar}.json").write_text(json.dumps(script, indent=1, ensure_ascii=False))
        desc = build_description(cfg, pillar, script, material)

        if dry:
            db.record_run(status="dry_run", **ctx)
            alert.send(f"[DRY RUN] Rendered '{script['title']}' ({dur:.0f}s, {pillar}). Not uploaded.")
            return
        vid, privacy = youtube.upload(video, script["title"], desc, script.get("tags", []),
                                      cfg["publish"]["category_id"], cfg["publish"]["privacy"])
        db.record_run(status="published", video_id=vid, **ctx)
        link = f"https://youtube.com/shorts/{vid}" if vid else "(check YouTube Studio in ~2 min)"
        alert.send(f"Posted ({privacy}): {script['title']}\n{link}")
    except Abort as e:
        db.record_run(status="skipped", error=str(e)[:2000], **ctx)
        alert.send(f"Skipped today ({pillar}), nothing posted.\nReason: {str(e)[:900]}")
    except Exception as e:
        db.record_run(status="error", error=traceback.format_exc()[-2000:], **ctx)
        alert.send(f"ERROR in daily run ({pillar}): {type(e).__name__}: {str(e)[:700]}")
        sys.exit(1)

if __name__ == "__main__":
    run()
