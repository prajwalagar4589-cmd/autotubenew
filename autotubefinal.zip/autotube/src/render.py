"""FFmpeg renderer: 1080x1920 Short with B-roll, styled captions, overlays, music, loudness normalisation."""
import os, random, subprocess, json, re
from .common import log, WORK, ASSETS, load_config
from .visuals import pexels_clip

W, H, FPS = 1080, 1920, 30
cfg = load_config()
PALETTES = [("0x0f172a", "0x1e3a8a"), ("0x111827", "0x7c2d12"), ("0x042f2e", "0x134e4a"),
            ("0x1e1b4b", "0x581c87"), ("0x0c0a09", "0x365314")]

def run(cmd):
    r = subprocess.run(cmd, capture_output=True, text=True, cwd=WORK)
    if r.returncode != 0:
        raise RuntimeError(f"ffmpeg failed: {' '.join(cmd[:6])}...\n{r.stderr[-1500:]}")
    return r

def _bg_segment(i, query, dur, used):
    out = WORK / f"seg_{i:02d}.mp4"
    vf = (f"scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H},setsar=1,fps={FPS},"
          "eq=brightness=-0.10:saturation=1.05,format=yuv420p")
    clip = pexels_clip(query, dur, used)
    if clip:
        cmd = ["ffmpeg", "-y", "-stream_loop", "-1", "-i", str(clip), "-t", f"{dur:.3f}", "-vf", vf, "-an"]
    else:
        c0, c1 = random.choice(PALETTES)
        cmd = ["ffmpeg", "-y", "-f", "lavfi", "-i",
               f"gradients=s={W}x{H}:c0={c0}:c1={c1}:x0=0:y0=0:x1={W}:y1={H}:speed=0.008:rate={FPS}",
               "-t", f"{dur:.3f}", "-vf", "format=yuv420p"]
    run(cmd + ["-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-r", str(FPS), str(out)])
    return out

def _ts(t):
    h = int(t // 3600); m = int(t % 3600 // 60); s = t % 60
    return f"{h}:{m:02d}:{s:05.2f}"

def _esc(t):
    return t.replace("\\", "").replace("{", "(").replace("}", ")").replace("\n", " ")

def _chunks(words, max_words=3):
    chunk = []
    for w in words:
        chunk.append(w)
        if len(chunk) >= max_words or re.search(r"[.,!?;:]$", w[0]):
            yield chunk; chunk = []
    if chunk: yield chunk

def build_ass(script, seg_t, words, total, pillar):
    name = cfg["channel"]["name"]
    head = f"""[Script Info]
ScriptType: v4.00+
PlayResX: {W}
PlayResY: {H}
WrapStyle: 0

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Cap,Poppins,86,&H00FFFFFF,&H00FFFFFF,&H00000000,&H80000000,-1,0,0,0,100,100,0,0,1,7,3,2,80,80,560,1
Style: Head,Poppins,64,&H00FFFFFF,&H00FFFFFF,&H00000000,&HB0101010,-1,0,0,0,100,100,0,0,3,22,0,8,90,90,230,1
Style: StatV,Poppins,210,&H0000D7FF,&H0000D7FF,&H00000000,&H80000000,-1,0,0,0,100,100,0,0,1,8,4,5,60,60,0,1
Style: StatL,Poppins,62,&H00FFFFFF,&H00FFFFFF,&H00000000,&H80000000,-1,0,0,0,100,100,0,0,1,5,2,5,60,60,0,1
Style: Tag,Poppins,34,&H00FFFFFF,&H00FFFFFF,&H00000000,&H90000000,0,0,0,0,100,100,1,0,3,10,0,7,40,40,70,1
Style: Brand,Poppins,40,&H00FFFFFF,&H00FFFFFF,&H00000000,&H80000000,-1,0,0,0,100,100,1,0,1,3,1,3,50,50,90,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
    ev = []
    ev.append(f"Dialogue: 3,{_ts(0)},{_ts(total)},Tag,,0,0,0,,AI-generated · {pillar.replace('_',' ').title()}")
    ev.append(f"Dialogue: 3,{_ts(0)},{_ts(total)},Brand,,0,0,0,,{_esc(name)}")
    for (a, b), s in zip(seg_t, script["segments"]):
        if s.get("overlay"):
            ev.append(f"Dialogue: 2,{_ts(a)},{_ts(b)},Head,,0,0,0,,{{\\fad(150,100)}}{_esc(s['overlay'])}")
        st = s.get("stat")
        if isinstance(st, dict) and st.get("value"):
            ev.append(f"Dialogue: 2,{_ts(a)},{_ts(b)},StatV,,0,0,0,,{{\\pos({W//2},{int(H*0.40)})\\fad(120,100)\\fscx70\\fscy70\\t(0,220,\\fscx100\\fscy100)}}{_esc(str(st['value']))}")
            ev.append(f"Dialogue: 2,{_ts(a)},{_ts(b)},StatL,,0,0,0,,{{\\pos({W//2},{int(H*0.40)+170})\\fad(200,100)}}{_esc(str(st.get('label','')))}")
    chunks = list(_chunks(words))
    for ci, ch in enumerate(chunks):
        nxt = chunks[ci + 1][0][1] if ci + 1 < len(chunks) else ch[-1][2] + 0.3
        for k, (w, ws, we) in enumerate(ch):
            end = ch[k + 1][1] if k + 1 < len(ch) else min(we + 0.3, nxt)
            parts = [(r"{\c&H0000D7FF&\fscx108\fscy108}" + _esc(x.upper()) + r"{\r}") if j == k else _esc(x.upper())
                     for j, (x, _, _) in enumerate(ch)]
            ev.append(f"Dialogue: 1,{_ts(ws)},{_ts(end)},Cap,,0,0,0,,{' '.join(parts)}")
    path = WORK / "captions.ass"
    path.write_text(head + "\n".join(ev) + "\n", encoding="utf-8")
    return path

def render(script, narration_wav, seg_t, words, pillar):
    total = seg_t[-1][1] + 0.4
    used = set()
    segs = []
    for i, ((a, b), s) in enumerate(zip(seg_t, script["segments"])):
        dur = (b - a) + (0.4 if i == len(seg_t) - 1 else 0)
        segs.append(_bg_segment(i, s["visual"], dur, used))
    lst = WORK / "concat.txt"
    lst.write_text("".join(f"file '{p.name}'\n" for p in segs))
    bg = WORK / "bg.mp4"
    run(["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", str(lst), "-c", "copy", str(bg)])

    ass = build_ass(script, seg_t, words, total, pillar)
    fonts = ASSETS / "fonts"
    music = sorted([p for p in (ASSETS / "music").glob("*") if p.suffix.lower() in (".mp3", ".wav", ".m4a", ".ogg")])
    out = WORK / "final.mp4"
    vf = f"[0:v]ass={ass.name}:fontsdir={fonts}[v]"
    inputs = ["-i", str(bg), "-i", str(narration_wav)]
    if music:
        inputs += ["-stream_loop", "-1", "-i", str(random.choice(music))]
        af = ("[2:a]volume=0.13,afade=t=in:d=1[m];[1:a]asplit=2[n1][n2];"
              "[m][n1]sidechaincompress=threshold=0.03:ratio=6:attack=20:release=400[md];"
              f"[n2][md]amix=inputs=2:duration=first:normalize=0,apad=whole_dur={total:.2f},"
              "loudnorm=I=-14:TP=-1.5:LRA=11[a]")
    else:
        af = f"[1:a]apad=whole_dur={total:.2f},loudnorm=I=-14:TP=-1.5:LRA=11[a]"
    run(["ffmpeg", "-y", *inputs, "-filter_complex", vf + ";" + af, "-map", "[v]", "-map", "[a]",
         "-t", f"{total:.2f}", "-c:v", "libx264", "-preset", "medium", "-crf", "19", "-pix_fmt", "yuv420p",
         "-r", str(FPS), "-c:a", "aac", "-b:a", "192k", "-ar", "48000", "-movflags", "+faststart", str(out)],)
    log.info(f"Rendered {out} ({total:.1f}s)")
    return out
