"""First-run health check: python -m src.doctor"""
import os
from .common import load_config
from . import ingest

cfg = load_config()
print("== Secrets ==")
for k in ["NVIDIA_API_KEY", "OPENROUTER_API_KEY", "PEXELS_API_KEY", "PIPEDREAM_WEBHOOK_URL", "PIPEDREAM_TOKEN",
          "TELEGRAM_BOT_TOKEN", "TELEGRAM_CHAT_ID", "YT_REFRESH_TOKEN (optional)"]:
    k = k.split(" ")[0]
    print(f"  {k:22s} {'set' if os.environ.get(k) else 'MISSING'}")
print("== LLM ==")
from .llm import chat
for role in ("writer", "checker"):
    try:
        print(f"  {role}: ok ->", chat(role, "Reply with JSON only.", 'Return {"ok": true}', attempts_per_model=1))
    except Exception as e:
        print(f"  {role}: FAILED {e}")
print("== YouTube ==")
cid = cfg["publish"].get("channel_id")
if cid:
    try:
        from .analytics import rss_stats
        s = rss_stats(cid); print(f"  channel RSS ok, {len(s)} videos visible")
    except Exception as e:
        print("  channel RSS FAILED:", e)
else:
    print("  publish.channel_id not set in config.yaml (analytics disabled until set)")
print("  upload method:", "Pipedream" if os.environ.get("PIPEDREAM_WEBHOOK_URL") else
      ("YouTube API" if os.environ.get("YT_REFRESH_TOKEN") else "NONE CONFIGURED"))
print("== Feeds ==")
for pillar, urls in cfg["sources"].items():
    if urls:
        items, health = ingest.fetch(urls, 72)
        print(f"  {pillar}: {len(items)} fresh items")
        for u, h in health.items(): print(f"     {h:18s} {u}")
