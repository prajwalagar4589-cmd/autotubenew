import sqlite3, json
from .common import DATA

DB = DATA / "state.db"

def conn():
    c = sqlite3.connect(DB)
    c.execute("""CREATE TABLE IF NOT EXISTS runs(
        id INTEGER PRIMARY KEY, day TEXT, pillar TEXT, format TEXT, status TEXT,
        title TEXT, topic TEXT, source_urls TEXT, video_id TEXT, error TEXT,
        script_json TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP)""")
    c.execute("""CREATE TABLE IF NOT EXISTS stats(
        video_id TEXT, fetched_at TEXT, views INT, likes INT, comments INT,
        avg_view_pct REAL, PRIMARY KEY(video_id, fetched_at))""")
    return c

def record_run(**kw):
    c = conn()
    cols = ",".join(kw); qs = ",".join("?" * len(kw))
    vals = [json.dumps(v) if isinstance(v, (list, dict)) else v for v in kw.values()]
    c.execute(f"INSERT INTO runs({cols}) VALUES({qs})", vals); c.commit(); c.close()

def already_ran(day):
    c = conn()
    r = c.execute("SELECT 1 FROM runs WHERE day=? AND status='published'", (day,)).fetchone()
    c.close(); return bool(r)

def recent_titles(n=60):
    c = conn()
    rows = c.execute("SELECT title, topic FROM runs WHERE status='published' ORDER BY id DESC LIMIT ?", (n,)).fetchall()
    c.close(); return [f"{t} | {tp}" for t, tp in rows]

def used_urls():
    c = conn(); urls = set()
    for (s,) in c.execute("SELECT source_urls FROM runs WHERE status='published'"):
        try: urls.update(json.loads(s or "[]"))
        except Exception: pass
    c.close(); return urls

def recent_formats(n=4):
    c = conn()
    rows = [r[0] for r in c.execute("SELECT format FROM runs WHERE status='published' ORDER BY id DESC LIMIT ?", (n,))]
    c.close(); return rows

def published_videos(limit=60):
    c = conn()
    rows = c.execute("SELECT video_id, pillar, format, title FROM runs WHERE status='published' AND video_id IS NOT NULL ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
    c.close(); return rows

def published_runs(limit=60):
    c = conn()
    rows = c.execute("SELECT id, video_id, pillar, format, title FROM runs WHERE status='published' ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
    c.close(); return rows

def set_video_id(run_id, vid):
    c = conn(); c.execute("UPDATE runs SET video_id=? WHERE id=?", (vid, run_id)); c.commit(); c.close()
