"""OpenAI-compatible client with a fallback chain across free providers.
Free endpoints do not enforce JSON, so every JSON call is validated and retried."""
import os, re, json, time
from openai import OpenAI
from .common import load_config, log, Abort

_cfg = load_config()

def _client(provider):
    p = _cfg["providers"][provider]
    key = os.environ.get(p["key_env"])
    if not key:
        return None
    return OpenAI(base_url=p["base_url"], api_key=key, timeout=240, max_retries=1)

def _extract_json(text):
    text = re.sub(r"<think>.*?</think>", "", text or "", flags=re.S).strip()
    text = re.sub(r"^```(?:json)?|```$", "", text.strip(), flags=re.M).strip()
    start = min([i for i in (text.find("{"), text.find("[")) if i != -1], default=-1)
    if start == -1:
        raise ValueError("no JSON found")
    opener = text[start]; closer = "}" if opener == "{" else "]"
    end = text.rfind(closer)
    return json.loads(text[start:end + 1])

def chat(role, system, user, want_json=True, validate=None, temperature=0.6, attempts_per_model=2):
    """role = 'writer' or 'checker'. validate(obj) should raise on bad output."""
    errors = []
    for m in _cfg["llm"][role]:
        client = _client(m["provider"])
        if client is None:
            errors.append(f"{m['provider']}: no API key"); continue
        for attempt in range(attempts_per_model):
            try:
                kwargs = dict(model=m["model"], temperature=temperature, max_tokens=6000,
                              messages=[{"role": "system", "content": system},
                                        {"role": "user", "content": user}])
                r = client.chat.completions.create(**kwargs)
                text = r.choices[0].message.content or ""
                if not want_json:
                    return re.sub(r"<think>.*?</think>", "", text, flags=re.S).strip()
                obj = _extract_json(text)
                if validate: validate(obj)
                log.info(f"LLM ok: {role} via {m['provider']}/{m['model']}")
                return obj
            except Exception as e:
                errors.append(f"{m['provider']}/{m['model']} try{attempt+1}: {str(e)[:200]}")
                log.warning(errors[-1]); time.sleep(5 * (attempt + 1))
    raise Abort(f"All {role} models failed: " + " || ".join(errors[-6:]))
