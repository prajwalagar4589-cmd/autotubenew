import json, subprocess, re, os
from .common import Abort, load_config

def probe(path):
    r = subprocess.run(["ffprobe", "-v", "error", "-show_entries",
                        "stream=codec_type,width,height,pix_fmt:format=duration,size", "-of", "json", str(path)],
                       capture_output=True, text=True)
    return json.loads(r.stdout)

def check(path):
    cfg = load_config()
    p = probe(path); problems = []
    streams = p.get("streams", []); fmt = p.get("format", {})
    v = [s for s in streams if s["codec_type"] == "video"]; a = [s for s in streams if s["codec_type"] == "audio"]
    if not v or (v[0].get("width"), v[0].get("height")) != (1080, 1920): problems.append("video must be 1080x1920")
    if not a: problems.append("no audio stream")
    d = float(fmt.get("duration", 0))
    if not (15 <= d <= cfg["publish"]["max_duration_sec"] + 2): problems.append(f"duration {d:.1f}s out of range")
    if int(fmt.get("size", 0)) < 300_000: problems.append("file suspiciously small")
    if a and not os.environ.get("AUTOTUBE_TEST_TTS"):
        r = subprocess.run(["ffmpeg", "-i", str(path), "-af", "volumedetect", "-vn", "-f", "null", "-"],
                           capture_output=True, text=True)
        m = re.search(r"mean_volume: (-?[\d\.]+) dB", r.stderr)
        if not m or float(m.group(1)) < -40: problems.append("audio is near-silent")
    if problems:
        raise Abort("QA failed: " + "; ".join(problems))
    return d
