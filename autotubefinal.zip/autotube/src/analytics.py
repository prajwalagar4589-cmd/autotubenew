"""Weekly: pull performance, write data/insights.md which softly steers topic choice.
Works without Google Cloud: reads the channel's public RSS feed (latest 15 videos, view counts).
If YouTube API credentials exist, it uses the API instead (more videos + retention)."""
import os, json, datetime as dt, requests, xml.etree.ElementTree as ET
from collections import defaultdict
from .common import log, DATA, load_config
from . import db, alert
from .llm import chat

NS = {"a": "http://www.w3.org/2005/Atom", "yt": "http://www.youtube.com/xml/schemas/2015",
      "media": "http://search.yahoo.com/mrss/"}

def rss_stats(channel_id):
    r = requests.get(f"https://www.youtube.com/feeds/videos.xml?channel_id={channel_id}", timeout=30)
    r.raise_for_status()
    out = {}
    for e in ET.fromstring(r.content).findall("a:entry", NS):
        vid = e.findtext("yt:videoId", namespaces=NS); title = e.findtext("a:title", namespaces=NS) or ""
        st = e.find("media:group/media:community/media:statistics", NS)
        rt = e.find("media:group/media:community/media:starRating", NS)
        out[vid] = {"title": title, "views": int(st.get("views", 0)) if st is not None else 0,
                    "likes": int(rt.get("count", 0)) if rt is not None else 0}
    return out

def api_stats(ids):
    from . import youtube
    stats = {}; yt = youtube.client()
    for i in range(0, len(ids), 50):
        r = yt.videos().list(part="statistics,snippet", id=",".join(ids[i:i+50])).execute()
        for it in r.get("items", []):
            s = it["statistics"]
            stats[it["id"]] = {"title": it["snippet"]["title"], "views": int(s.get("viewCount", 0)),
                               "likes": int(s.get("likeCount", 0))}
    return stats

def run():
    cfg = load_config()
    runs = db.published_runs(60)
    if not runs:
        log.info("No videos yet"); return
    if os.environ.get("YT_REFRESH_TOKEN"):
        stats = api_stats([r[1] for r in runs if r[1]])
    elif cfg["publish"].get("channel_id"):
        stats = rss_stats(cfg["publish"]["channel_id"])
    else:
        log.warning("Set publish.channel_id in config.yaml to enable analytics"); return

    by_title = {v["title"].strip().lower(): vid for vid, v in stats.items()}
    rows = []
    for run_id, vid, pillar, fmt, title in runs:
        if not vid and title and title.strip().lower() in by_title:
            vid = by_title[title.strip().lower()]; db.set_video_id(run_id, vid)
        if vid in stats:
            rows.append({"title": title, "pillar": pillar, "format": (fmt or "").split(":")[0], **stats[vid]})
    if not rows:
        (DATA / "insights.md").write_text("No matched videos with stats yet."); return

    c = db.conn(); now = dt.datetime.utcnow().isoformat()
    for r in rows:
        vid = by_title.get(r["title"].strip().lower())
        if vid: c.execute("INSERT OR REPLACE INTO stats VALUES(?,?,?,?,?,?)", (vid, now, r["views"], r["likes"], 0, None))
    c.commit(); c.close()

    agg = defaultdict(list)
    for r in rows: agg[r["pillar"]].append(r["views"])
    summary = {k: {"videos": len(v), "avg_views": round(sum(v) / len(v))} for k, v in agg.items()}
    memo = chat("writer", "You are a YouTube Shorts growth analyst. Be concrete and brief.",
        "Per-video data (newest first):\n" + json.dumps(rows[:40], ensure_ascii=False) +
        "\n\nPer-pillar summary:\n" + json.dumps(summary) +
        "\n\nWrite at most 8 bullet points of guidance for choosing next week's topics, hooks, titles and formats. "
        "Only patterns supported by the numbers. Never suggest clickbait, sensational politics, or anything that "
        "would compromise accuracy or neutrality.", want_json=False, temperature=0.3)
    (DATA / "insights.md").write_text(memo[:3000])
    tot = sum(r["views"] for r in rows)
    alert.send(f"Weekly report: {len(rows)} recent videos, {tot:,} views.\n" +
               "\n".join(f"{k}: {v['avg_views']:,} avg views ({v['videos']} videos)" for k, v in summary.items()))

if __name__ == "__main__":
    run()
