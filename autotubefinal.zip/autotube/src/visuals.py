"""Stock B-roll from the Pexels API (free). Falls back to animated gradients."""
import os, requests, hashlib
from .common import log, WORK

def pexels_clip(query, min_dur, used=None):
    used = used if used is not None else set()
    key = os.environ.get("PEXELS_API_KEY")
    if not key or os.environ.get("AUTOTUBE_TEST_TTS"):
        return None
    try:
        r = requests.get("https://api.pexels.com/videos/search", headers={"Authorization": key}, timeout=25,
                         params={"query": query, "orientation": "portrait", "per_page": 12, "size": "medium"})
        r.raise_for_status()
        vids = [v for v in r.json().get("videos", []) if v.get("duration", 0) >= min(min_dur, 6)]
        for v in vids:
            files = sorted([f for f in v["video_files"] if f.get("height") and f.get("width")
                            and f["height"] > f["width"] and 1280 <= f["height"] <= 2400],
                           key=lambda f: f["height"])
            if not files:
                continue
            f = files[0]
            path = WORK / f"bg_{hashlib.md5(f['link'].encode()).hexdigest()[:10]}.mp4"
            if str(path) in used:
                continue
            used.add(str(path))
            if not path.exists():
                with requests.get(f["link"], stream=True, timeout=60) as d:
                    d.raise_for_status()
                    with open(path, "wb") as fh:
                        for chunk in d.iter_content(1 << 20): fh.write(chunk)
            return path
    except Exception as e:
        log.warning(f"pexels failed for '{query}': {e}")
    return None
