"""Kokoro TTS (open source, CPU). Produces one wav per segment + word timings."""
import os, re, numpy as np, soundfile as sf
from .common import load_config, log, WORK

SR = 24000
PAUSE = 0.22  # seconds between segments
cfg = load_config()["tts"]
_pipe = None

def _pipeline():
    global _pipe
    if _pipe is None:
        from kokoro import KPipeline
        _pipe = KPipeline(lang_code=cfg["voice"][0], repo_id="hexgrad/Kokoro-82M")
    return _pipe

def _speak(text):
    if os.environ.get("AUTOTUBE_TEST_TTS"):  # sandbox/test mode: silent audio of realistic length
        return np.zeros(int(SR * len(text.split()) / 2.7), dtype=np.float32)
    chunks = []
    for res in _pipeline()(text, voice=cfg["voice"], speed=cfg["speed"]):
        audio = res[2] if isinstance(res, tuple) else res.audio
        chunks.append(np.asarray(audio, dtype=np.float32))
    return np.concatenate(chunks)

def _tts_text(t):
    # help the voice with Indian money shorthand
    t = re.sub(r"₹\s?([\d,\.]+)\s?(lakh|crore)", r"\1 \2 rupees", t, flags=re.I)
    t = re.sub(r"₹\s?([\d,\.]+)", r"\1 rupees", t)
    return t

def synthesize(segments):
    """Returns (wav_path, seg_timings[(start,end)], words[(word,start,end)])"""
    out, seg_t, words, t = [], [], [], 0.0
    gap = np.zeros(int(SR * PAUSE), dtype=np.float32)
    for s in segments:
        a = _speak(_tts_text(s["text"]))
        dur = len(a) / SR
        seg_t.append((t, t + dur + PAUSE))
        toks = s["text"].split()
        weights = [len(w) + 2 for w in toks]; total = sum(weights)
        speech_start, speech_len = t + 0.05, max(dur - 0.12, 0.3)
        cur = speech_start
        for w, wt in zip(toks, weights):
            d = speech_len * wt / total
            words.append((w, cur, cur + d)); cur += d
        out += [a, gap]; t += dur + PAUSE
    audio = np.concatenate(out)
    path = WORK / "narration.wav"
    sf.write(path, audio, SR)
    log.info(f"TTS done: {len(audio)/SR:.1f}s")
    return path, seg_t, words
