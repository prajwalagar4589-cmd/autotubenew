import json, re, requests
from .common import load_config, log, Abort
from .llm import chat

cfg = load_config()
CH = cfg["channel"]; COMP = cfg["compliance"]
UA = {"User-Agent": "autotube/1.0 (educational YouTube Shorts; contact via channel)"}

# ---------------- source material ----------------
def article_text(url, fallback=""):
    try:
        import trafilatura
        html = requests.get(url, headers={"User-Agent": "Mozilla/5.0"}, timeout=25).text
        txt = trafilatura.extract(html) or ""
        if len(txt) > 400:
            return txt[:5000]
    except Exception as e:
        log.warning(f"article fetch failed {url}: {e}")
    return fallback

def wikipedia(title):
    r = requests.get("https://en.wikipedia.org/w/api.php", headers=UA, timeout=25, params={
        "action": "query", "prop": "extracts|info", "explaintext": 1, "redirects": 1,
        "inprop": "url", "titles": title, "format": "json"})
    page = next(iter(r.json()["query"]["pages"].values()))
    if "missing" in page or len(page.get("extract", "")) < 800:
        return None
    return {"url": page["fullurl"], "title": page["title"], "text": page["extract"][:7000]}

# ---------------- topic selection ----------------
def pick_news(pillar, items, fmt, recent, insights):
    listing = "\n".join(f"[{i}] ({it['source']}) {it['title']} :: {it['summary'][:300]}" for i, it in enumerate(items))
    def v(o):
        assert isinstance(o.get("picks"), list) and o["picks"] and all(isinstance(i, int) and 0 <= i < len(items) for i in o["picks"])
        assert o.get("topic")
    o = chat("writer",
        f"You are the editor of the YouTube Shorts channel '{CH['name']}'. Audience: {CH['audience']}. "
        "You choose ONE story per day that is genuinely useful or interesting to this audience and can be "
        "explained accurately in under 60 seconds. Prefer stories relevant to India or with global impact. "
        "Avoid gossip, tragedy-as-entertainment, crime details, unverified rumours and anything already covered.",
        f"Pillar today: {pillar}\nFormat today: {fmt}\n\nAlready covered recently (do NOT repeat):\n"
        + "\n".join(recent[:40]) + f"\n\nWhat has been performing (use as a soft hint only):\n{insights}\n\n"
        f"Candidate items:\n{listing}\n\nReturn JSON only: "
        '{"picks":[indexes of 1-3 items about the SAME story],"topic":"one line","angle":"the specific angle for this audience","why":"one line"}',
        validate=v, temperature=0.4)
    return o

def pick_evergreen(pillar, fmt, recent, insights):
    def v(o):
        assert isinstance(o.get("candidates"), list) and len(o["candidates"]) >= 3
    o = chat("writer",
        f"You are the editor of the YouTube Shorts channel '{CH['name']}'. Audience: {CH['audience']}.",
        f"Pillar: {pillar}. Format: {fmt}.\nSuggest evergreen topics (concepts, how things work, surprising facts, "
        "history behind everyday things) that fit the pillar and would make someone stop scrolling. Each must have an "
        "exact English Wikipedia article title that covers it.\nAlready covered (do NOT repeat):\n" + "\n".join(recent[:40]) +
        f"\nPerformance hints: {insights}\n\nReturn JSON only: "
        '{"candidates":[{"topic":"...","angle":"...","wikipedia_title":"..."}, ...5 items]}',
        validate=v, temperature=0.9)
    for c in o["candidates"]:
        try:
            w = wikipedia(c["wikipedia_title"])
            if w:
                return {"topic": c["topic"], "angle": c["angle"],
                        "material": [{"url": w["url"], "source": "Wikipedia: " + w["title"], "text": w["text"]}]}
        except Exception as e:
            log.warning(f"wikipedia miss {c}: {e}")
    raise Abort("No evergreen candidate had a usable Wikipedia source")

# ---------------- script ----------------
SCHEMA = '''{
 "title": "YouTube title, max 70 chars, specific and searchable, no clickbait, no ALL CAPS, no emojis",
 "segments": [
   {"text": "narration, 1-2 short spoken sentences",
    "visual": "2-4 word stock-footage search query for a GENERIC scene (no logos, no brands, no real people, no politicians)",
    "overlay": "optional on-screen headline, max 6 words, or empty string",
    "stat": {"value": "optional big number e.g. 6.5%", "label": "what it is, max 5 words"} or null}
 ],
 "description": "2-3 sentence YouTube description in plain language",
 "tags": ["8-12 lowercase search tags"],
 "sources_used": ["urls of the material you actually used"]
}'''

def _rules(pillar):
    r = [
        "Use ONLY facts stated in the SOURCE MATERIAL. If it is not in the material, do not say it.",
        "Every number, name, date and claim must appear in the material. Do not round in misleading ways.",
        "First segment is the hook: a question or surprising fact in under 12 words. No 'Hey guys', no channel intro.",
        "5 to 8 segments, 110-145 words of narration total. Short sentences that sound natural when spoken aloud.",
        "Explain any jargon in plain words. Indian context where relevant (rupees, Indian examples).",
        "Final segment: one-line takeaway, then 'Follow for one smart minute every day.'",
        "Attribute: say 'according to <source>' at least once for news.",
        "No claims about private individuals. No medical or legal advice.",
    ]
    if pillar in COMP["finance_pillars"]:
        r.append("MONEY RULES: educational only. Never tell the viewer to buy, sell or hold anything, never name a stock as a pick, never predict prices or returns.")
    if pillar == "politics":
        r.append("POLITICS RULES: " + COMP["politics_rules"])
    return "\n".join(f"- {x}" for x in r)

def _validate_script(o):
    segs = o.get("segments")
    assert isinstance(segs, list) and 4 <= len(segs) <= 9, "segment count"
    words = sum(len(s.get("text", "").split()) for s in segs)
    assert 90 <= words <= 170, f"word count {words}"
    assert o.get("title") and len(o["title"]) <= 95, "title"
    for s in segs:
        assert s.get("text") and s.get("visual"), "segment fields"

def write_script(pillar, fmt, topic, angle, material, feedback=None):
    src = "\n\n".join(f"### SOURCE {i+1}: {m['source']} ({m['url']})\n{m['text']}" for i, m in enumerate(material))
    fb = f"\n\nA fact-checker rejected the previous draft for these reasons. Fix every one:\n{feedback}" if feedback else ""
    return chat("writer",
        f"You write scripts for '{CH['name']}', a YouTube Shorts channel. {CH['tagline']} Audience: {CH['audience']}. "
        f"Language: {CH['language']}. Tone: sharp, clear, trustworthy, a smart friend explaining something. Never hype.",
        f"Topic: {topic}\nAngle: {angle}\nFormat: {fmt}\nPillar: {pillar}\n\nRULES:\n{_rules(pillar)}\n{fb}\n\n"
        f"SOURCE MATERIAL:\n{src}\n\nReturn JSON only, matching:\n{SCHEMA}",
        validate=_validate_script, temperature=0.7)

# ---------------- fact-check gate ----------------
def hard_checks(pillar, script):
    text = " ".join(s["text"] + " " + (s.get("overlay") or "") for s in script["segments"]) + " " + script["title"]
    low = text.lower(); problems = []
    for p in COMP["banned_phrases"]:
        if p in low: problems.append(f"banned phrase: '{p}'")
    if re.search(r"\b(subscribe|smash that like)\b", low): problems.append("begging for engagement")
    return problems

def fact_check(pillar, script, material):
    src = "\n\n".join(f"### {m['source']} ({m['url']})\n{m['text']}" for m in material)
    narration = "\n".join(f"{i+1}. {s['text']}" + (f"  [on-screen: {s.get('overlay')}]" if s.get("overlay") else "")
                          + (f"  [stat: {s['stat']['value']} {s['stat']['label']}]" if s.get("stat") else "")
                          for i, s in enumerate(script["segments"]))
    extra = ""
    if pillar in COMP["finance_pillars"]:
        extra += "\n- FAIL if anything could be read as investment advice, a recommendation or a price/return prediction."
    if pillar == "politics":
        extra += "\n- FAIL if it is not strictly neutral: any opinion, loaded word, praise/criticism of a party/leader/government, or one-sided framing."
    def v(o): assert isinstance(o.get("pass"), bool) and isinstance(o.get("issues"), list)
    return chat("checker",
        "You are a strict fact-checker for a news explainer channel. You are sceptical and precise. "
        "You compare a script against its source material and nothing else.",
        f"TITLE: {script['title']}\nSCRIPT:\n{narration}\n\nSOURCE MATERIAL:\n{src}\n\nCheck:\n"
        "- FAIL if any number, date, name or factual claim is not supported by the source material, or is distorted.\n"
        "- FAIL if the title or hook misrepresents the story.\n"
        "- FAIL if it states speculation as fact, or makes claims about private individuals." + extra +
        "\n- Minor wording style is NOT a reason to fail.\n\nReturn JSON only: "
        '{"pass": true/false, "issues": [{"line": n, "problem": "...", "fix": "..."}]}',
        validate=v, temperature=0.0)

def produce(pillar, fmt, topic, angle, material):
    feedback = None
    for round_ in range(3):
        script = write_script(pillar, fmt, topic, angle, material, feedback)
        problems = hard_checks(pillar, script)
        verdict = fact_check(pillar, script, material)
        if not problems and verdict["pass"]:
            log.info(f"Script passed fact-check on round {round_+1}")
            return script
        feedback = json.dumps(problems + verdict["issues"], indent=1)
        log.warning(f"Round {round_+1} rejected: {feedback[:500]}")
    raise Abort("Script failed fact-check 3 times; skipping today (fail-closed). Last issues: " + (feedback or "")[:600])
