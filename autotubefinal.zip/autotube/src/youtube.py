import os, requests
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload
from googleapiclient.errors import HttpError
from .common import log

SCOPES = ["https://www.googleapis.com/auth/youtube",
          "https://www.googleapis.com/auth/yt-analytics.readonly"]

def creds():
    c = Credentials(None, refresh_token=os.environ["YT_REFRESH_TOKEN"], token_uri="https://oauth2.googleapis.com/token",
                    client_id=os.environ["YT_CLIENT_ID"], client_secret=os.environ["YT_CLIENT_SECRET"], scopes=SCOPES)
    return c

def client():
    return build("youtube", "v3", credentials=creds(), cache_discovery=False)

def analytics_client():
    return build("youtubeAnalytics", "v2", credentials=creds(), cache_discovery=False)

def upload(path, title, description, tags, category_id, privacy):
    if os.environ.get("PIPEDREAM_WEBHOOK_URL"):
        return upload_via_pipedream(path, title, description, tags, category_id, privacy)
    return upload_via_api(path, title, description, tags, category_id, privacy)

def upload_via_pipedream(path, title, description, tags, category_id, privacy):
    """POST the video to a Pipedream workflow (HTTP trigger -> YouTube 'Upload Video').
    Pipedream stores the file and passes a URL to its YouTube action, using Pipedream's
    own verified YouTube connection, so no Google Cloud project is needed."""
    headers = {}
    if os.environ.get("PIPEDREAM_TOKEN"):
        headers["Authorization"] = f"Bearer {os.environ['PIPEDREAM_TOKEN']}"
    with open(path, "rb") as f:
        r = requests.post(os.environ["PIPEDREAM_WEBHOOK_URL"], headers=headers, timeout=300,
                          data={"title": title[:100], "description": description[:4900],
                                "tags": ",".join(tags[:15]), "privacy": privacy, "category_id": category_id},
                          files={"video": (os.path.basename(str(path)), f, "video/mp4")})
    if r.status_code >= 300:
        raise RuntimeError(f"Pipedream webhook returned {r.status_code}: {r.text[:300]}")
    log.info(f"Handed video to Pipedream ({r.status_code}); it uploads to YouTube within ~1-2 minutes")
    vid = None
    try:
        vid = (r.json() or {}).get("id")   # only if the workflow is set to return the video id
    except Exception:
        pass
    return vid, privacy

def upload_via_api(path, title, description, tags, category_id, privacy):
    yt = client()
    body = {"snippet": {"title": title[:100], "description": description[:4900], "tags": tags[:15],
                        "categoryId": category_id, "defaultLanguage": "en", "defaultAudioLanguage": "en"},
            "status": {"privacyStatus": privacy, "selfDeclaredMadeForKids": False,
                       "containsSyntheticMedia": True}}
    def _go(b):
        req = yt.videos().insert(part="snippet,status", body=b,
                                 media_body=MediaFileUpload(str(path), mimetype="video/mp4", chunksize=8 << 20, resumable=True))
        resp = None
        while resp is None:
            _, resp = req.next_chunk()
        return resp
    try:
        resp = _go(body)
    except HttpError as e:
        if "containsSyntheticMedia" in str(e):
            log.warning("API rejected containsSyntheticMedia field; uploading with disclosure in description only")
            body["status"].pop("containsSyntheticMedia"); resp = _go(body)
        else:
            raise
    vid = resp["id"]
    log.info(f"Uploaded https://youtube.com/shorts/{vid} ({resp.get('status', {}).get('privacyStatus')})")
    return vid, resp.get("status", {}).get("privacyStatus")

def whoami():
    r = client().channels().list(part="snippet,statistics", mine=True).execute()
    it = r["items"][0]
    return it["snippet"]["title"], it["statistics"]
