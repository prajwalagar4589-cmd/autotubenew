"""Generates branding/avatar.png (800x800) and branding/banner.png (2560x1440)."""
from PIL import Image, ImageDraw, ImageFont
import yaml
cfg = yaml.safe_load(open("config.yaml"))["channel"]
F = "assets/fonts/Poppins-Bold.ttf"; FM = "assets/fonts/Poppins-Medium.ttf"
NAVY, BLUE, YEL, WHITE = (12, 18, 38), (30, 58, 138), (255, 215, 0), (255, 255, 255)

def grad(w, h):
    im = Image.new("RGB", (w, h)); d = ImageDraw.Draw(im)
    for y in range(h):
        t = y / h; d.line([(0, y), (w, y)], fill=tuple(int(NAVY[i] * (1 - t) + BLUE[i] * t) for i in range(3)))
    return im

# avatar: a stopwatch-style ring with a big "1"
a = grad(800, 800); d = ImageDraw.Draw(a)
d.arc([110, 110, 690, 690], start=-90, end=240, fill=YEL, width=46)
d.arc([110, 110, 690, 690], start=240, end=270, fill=(255, 255, 255, 80), width=46)
d.rounded_rectangle([370, 40, 430, 100], radius=10, fill=YEL)
f = ImageFont.truetype(F, 330)
d.text((400, 385), "1", font=f, fill=WHITE, anchor="mm")
f2 = ImageFont.truetype(F, 58)
d.text((400, 575), "MIN", font=f2, fill=YEL, anchor="mm")
a.save("branding/avatar.png")

# banner: all text inside YouTube's 1546x423 safe area
b = grad(2560, 1440); d = ImageDraw.Draw(b)
cx, cy = 1280, 720
d.text((cx, cy - 70), cfg["name"], font=ImageFont.truetype(F, 150), fill=WHITE, anchor="mm")
d.text((cx, cy + 60), "AI · Tech · Money · Engineering · The World", font=ImageFont.truetype(FM, 56), fill=YEL, anchor="mm")
d.text((cx, cy + 150), "A new one-minute explainer every day", font=ImageFont.truetype(FM, 44), fill=(200, 210, 230), anchor="mm")
b.save("branding/banner.png")
print("saved branding/avatar.png and branding/banner.png")
