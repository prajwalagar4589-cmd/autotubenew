"""Run ONCE on your own computer (needs a browser):
    pip install google-auth-oauthlib
    python scripts/get_refresh_token.py path/to/client_secret.json
Sign in with the Google account that owns the channel, pick the channel, allow access.
It prints YT_CLIENT_ID, YT_CLIENT_SECRET and YT_REFRESH_TOKEN for GitHub Secrets."""
import sys, json
from google_auth_oauthlib.flow import InstalledAppFlow
SCOPES = ["https://www.googleapis.com/auth/youtube", "https://www.googleapis.com/auth/yt-analytics.readonly"]
path = sys.argv[1] if len(sys.argv) > 1 else "client_secret.json"
flow = InstalledAppFlow.from_client_secrets_file(path, SCOPES)
creds = flow.run_local_server(port=8080, access_type="offline", prompt="consent")
info = json.load(open(path)); info = info.get("installed") or info.get("web")
print("\nAdd these three as GitHub repository secrets:\n")
print("YT_CLIENT_ID     =", info["client_id"])
print("YT_CLIENT_SECRET =", info["client_secret"])
print("YT_REFRESH_TOKEN =", creds.refresh_token)
