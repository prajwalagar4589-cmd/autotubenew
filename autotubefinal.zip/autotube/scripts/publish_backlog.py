"""After the API audit passes: set config publish.privacy to "public", then run this
(via the 'Publish backlog' workflow) to try flipping earlier private uploads to public."""
from src import db, youtube
yt = youtube.client()
for vid, pillar, fmt, title in db.published_videos(500):
    try:
        yt.videos().update(part="status", body={"id": vid, "status": {
            "privacyStatus": "public", "selfDeclaredMadeForKids": False, "containsSyntheticMedia": True}}).execute()
        print("public:", title)
    except Exception as e:
        print("could not flip:", title, str(e)[:150])
