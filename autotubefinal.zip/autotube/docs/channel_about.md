# Paste into YouTube Studio → Customization

**Channel name:** One Smart Minute
**Handle:** @onesmartminute (or the closest free variant)

**Description:**
AI, tech, money, engineering and the world, explained in one minute.

A new Short every day at 6 PM IST: what happened, why it matters, and what it means for you.

How this channel works: every video is fully AI-generated (script, voice and edit) from public
sources that are linked in each description, and every script is fact-checked by a second AI
model before it is published. Money videos are educational only, never investment advice.
Politics is covered neutrally and factually.

**Links:** your GitHub Pages homepage (from the site repo)

**Avatar:** branding/avatar.png   **Banner:** branding/banner.png
