# Draft answers: YouTube API Services – Audit and Quota Extension Form

Use these to fill the form (search "YouTube API Services Audit and Quota Extension Form").
Choose the option for an **audit only** (you do NOT need extra quota: the default
10,000 units/day covers one upload a day with plenty of headroom).
Replace CONTACT_EMAIL, the GitHub Pages URL and the channel URL before submitting.

**API client name:** One Smart Minute publishing tool

**Google Cloud project number:** (Cloud Console → project dashboard)

**Is the API client publicly available?** No. Internal tool used only by the channel owner.

**Describe your API client / how it uses the API:**
An internal, server-side publishing tool used by a single content creator to publish one
original educational YouTube Short per day to their own channel. It uses videos.insert to
upload the video with its title, description and tags, and with the altered/synthetic
content disclosure set, since videos are AI-produced. It uses videos.list and the YouTube
Analytics API (reports.query) to read aggregate statistics for the channel's own videos,
which help choose future topics. It uses videos.update only to change the privacy status
of the channel's own videos. The tool acts only on the owner's channel through the
owner's own OAuth consent. It has no other users, no UI, and does not access any other
user's or viewer's data.

**API services used:** YouTube Data API v3, YouTube Analytics API

**OAuth scopes:** youtube, yt-analytics.readonly

**Website / privacy policy URL:** https://<your-github-username>.github.io/<site-repo>/privacy.html

**Homepage URL:** https://<your-github-username>.github.io/<site-repo>/

**Channel URL:** https://www.youtube.com/@<handle>

**Expected usage:** ~1 upload/day, ~30–60 read calls/week. Well under default quota.

**Does the client display YouTube data to users?** No.

**Does the client store YouTube data?** Only video IDs and aggregate stats of the owner's
own videos, used internally, refreshed weekly; deleted on revocation.

If asked for a demo/screencast: record your screen running the "Daily Short" workflow in
GitHub Actions (dry run, then a real private upload), then show the video in YouTube Studio.
